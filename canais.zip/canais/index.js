const fs = require('fs');

function testarLocalmente() {
    console.log('🔄 Iniciando teste com dados JSON de exemplo...');

    // 1. Simula um retorno JSON estruturado de canais
    const canaisExemplo = [
        { id: "globo.br", name: "Globo HD", logo: "http://logo.com/globo.png", country: "BR", url: "http://stream.exemplo.com/globo/index.m3u8" },
        { id: "sbt.br", name: "SBT HD", logo: "http://logo.com/sbt.png", country: "BR", url: "http://stream.exemplo.com/sbt/index.m3u8" },
        { id: "record.br", name: "Record HD", logo: "http://logo.com/record.png", country: "BR", url: "http://stream.exemplo.com/record/index.m3u8" },
        { id: "espn.br", name: "ESPN HD", logo: "http://logo.com/espn.png", country: "BR", url: "http://stream.exemplo.com/espn/index.m3u8" }
    ];

    try {
        // 2. Salva os dados brutos no arquivo canais_iptv.json
        fs.writeFileSync('canais_iptv.json', JSON.stringify(canaisExemplo, null, 2), 'utf-8');
        console.log('💾 Arquivo "canais_iptv.json" salvo com sucesso!');

        // 3. Monta e gera o arquivo lista_gerada.m3u
        console.log('📝 Gerando arquivo de lista M3U formatada...');
        let m3uContent = '#EXTM3U\n';

        canaisExemplo.forEach(canal => {
            m3uContent += `#EXTINF:-1 tvg-id="${canal.id}" tvg-name="${canal.name}" tvg-logo="${canal.logo}" group-title="${canal.country}",${canal.name}\n`;
            m3uContent += `${canal.url}\n`;
        });

        fs.writeFileSync('lista_gerada.m3u', m3uContent, 'utf-8');
        console.log('📁 Arquivo "lista_gerada.m3u" gerado com sucesso no VS Code!');

    } catch (error) {
        console.error('❌ Erro durante o processamento:', error);
    }
}

testarLocalmente();